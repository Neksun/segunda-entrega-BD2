package edu.uao.project.backend.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Data
@AllArgsConstructor
@NoArgsConstructor

@Document(collection = "Tutors")
public class MTutors {

    @Id
    private ObjectId _id;
    private String nombreT;
    private String carrera;
    private Integer semestre;
    private Double calificacion_promedio;
}