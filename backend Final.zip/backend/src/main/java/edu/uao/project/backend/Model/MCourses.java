package edu.uao.project.backend.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Data
@AllArgsConstructor
@NoArgsConstructor

@Document(collection = "Courses") // Specify the MongoDB collection name
public class MCourses {

    @Id
    private ObjectId _id;
    private String name;
    private String category;
    private Double price;
    private Integer totalHours;
    private Double Rating;
}
