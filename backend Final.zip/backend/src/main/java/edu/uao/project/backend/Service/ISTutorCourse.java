package edu.uao.project.backend.Service;

public interface ISTutorCourse {
}
