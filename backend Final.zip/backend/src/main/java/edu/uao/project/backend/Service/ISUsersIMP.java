package edu.uao.project.backend.Service;


import edu.uao.project.backend.Model.MUsers;

import edu.uao.project.backend.Repository.IRUsers;


public class ISUsersIMP implements ISUsers {
    IRUsers UsersRepository;
    @Override
    public String crearUser(MUsers users) {
        this. UsersRepository.save(users);
        return "El Usuario " + users.getNombre() + " fue creado exitosamente";
    }
}
