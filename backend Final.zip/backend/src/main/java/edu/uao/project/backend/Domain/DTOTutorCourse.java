package edu.uao.project.backend.Domain;

public class DTOTutorCourse {
}
