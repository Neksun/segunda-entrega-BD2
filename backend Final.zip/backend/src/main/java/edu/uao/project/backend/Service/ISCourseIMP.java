package edu.uao.project.backend.Service;

import edu.uao.project.backend.Model.MCourses;
import edu.uao.project.backend.Repository.IRCourses;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ISCourseIMP implements ISCourse {
    @Autowired
    IRCourses coursesRepository;

    @Override
    public String crearCurso(MCourses course) {
        this.coursesRepository.save(course);
        return "El curso " + course.getName() + " fue creado exitosamente";
    }



}
