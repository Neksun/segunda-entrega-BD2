package edu.uao.project.backend.Controller;

import edu.uao.project.backend.Model.MTutors;
import edu.uao.project.backend.Repository.IRTutors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Tutors")
public class CTutors {
    @Autowired
    private IRTutors TutorsRepository;

    @PostMapping("/")
    public ResponseEntity<MTutors> crearTutors(@RequestBody MTutors tutors) {
        MTutors savedTutors = TutorsRepository.save(tutors);
        return ResponseEntity.ok(savedTutors);
    }
}
