package edu.uao.project.backend.Service;

import edu.uao.project.backend.Model.MCourses;
import edu.uao.project.backend.Model.MTutors;
import edu.uao.project.backend.Repository.IRTutors;
import org.springframework.beans.factory.annotation.Autowired;

public class ISTutorsIMP implements ISTutors{
    IRTutors TutorsRepository;
    @Override
    public String crearTutors(MTutors tutors) {
        this.TutorsRepository.save(tutors);
        return "El Tutor " + tutors.getNombreT() + " fue creado exitosamente";
    }
}
