package edu.uao.project.backend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.List;


@RestController
@RequestMapping("/TutorCourse")
public class CTutorCourse {
    @Autowired
    private MongoTemplate mongoTemplate;

    @GetMapping("/Consulta2")
    public List<TutorCourseProjection> TutorCourseRating() {
        LookupOperation tutorLookup = LookupOperation.newLookup()
                .from("Tutors")
                .localField("Tutor_id")
                .foreignField("_id")
                .as("tutor");

        LookupOperation cursoLookup = LookupOperation.newLookup()
                .from("Courses")
                .localField("cursos.Curso_id")
                .foreignField("_id")
                .as("curso");

        Aggregation aggregation = Aggregation.newAggregation(
                tutorLookup,
                cursoLookup,
                Aggregation.unwind("curso"),
                Aggregation.match(Criteria.where("curso.Rating").gt(3.6)),
                Aggregation.project()
                        .andExclude("_id")
                        .andExpression("curso.name").as("nombreCurso")
                        .andExpression("curso.Rating").as("ratingCurso")
                        .andExpression("cursos.Curso_id").as("curso_id")
                        .andExpression("tutor").as("infoTutor")
        );

        return mongoTemplate.aggregate(aggregation, "TutorCourse", TutorCourseProjection.class).getMappedResults();
    }
}
