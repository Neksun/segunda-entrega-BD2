package edu.uao.project.backend.Repository;

import edu.uao.project.backend.Model.MCourses;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.repository.MongoRepository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;

import java.util.Arrays;
import java.util.List;
import static javax.management.Query.match;
import static org.springframework.data.mongodb.core.query.Query.query;

import org.springframework.data.mongodb.core.aggregation.Aggregation;

@Repository
public interface IRCourses extends MongoRepository<MCourses, ObjectId> {
    //@Query(value = "{ $match: { Rating: { $gt: 4.0 } } }", nativeQuery = true)
    //List<MCourses> findByRatingGreaterThan(double rating);
    List<MCourses> findByRatingGreaterThan(double rating);


}
