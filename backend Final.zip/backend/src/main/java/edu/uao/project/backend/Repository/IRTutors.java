package edu.uao.project.backend.Repository;

import edu.uao.project.backend.Model.MTutors;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IRTutors extends MongoRepository<MTutors, ObjectId> {
}
