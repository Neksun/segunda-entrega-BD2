package com.artesanias.tiendaArtesanias.Exception;

public class CamposInvalidosException extends RuntimeException{
    public CamposInvalidosException (String mensaje){
        super(mensaje);
    }
}

