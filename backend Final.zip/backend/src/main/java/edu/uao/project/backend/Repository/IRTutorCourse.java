package edu.uao.project.backend.Repository;

import edu.uao.project.backend.Controller.TutorCourseProjection;

import java.util.List;

public interface IRTutorCourse {
    List<TutorCourseProjection> TutorCourseRating();

}
