package edu.uao.project.backend.Controller;

import edu.uao.project.backend.Model.MCourses;
import edu.uao.project.backend.Repository.IRCourses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
//Karol payares 2221343
@RestController
@RequestMapping("/Courses")
public class CCourses {
    @Autowired
    private IRCourses coursesRepository;

    @PostMapping("/")
    public ResponseEntity<MCourses> crearCurso(@RequestBody MCourses course) {
        MCourses savedCourse = coursesRepository.save(course); // Save the course to the database
        return ResponseEntity.ok(savedCourse); // Return the saved course with HTTP status 200 (OK)
    }

    @Autowired
    private MongoTemplate mongoTemplate;
    @GetMapping("/Consulta1")
    public List<MCourses> findByRatingGreaterThan() {
        Criteria criteria = Criteria.where("Rating").gt(4.0);
        MatchOperation matchRatingGreaterThan4 = Aggregation.match(criteria);
        Aggregation aggregation = Aggregation.newAggregation(matchRatingGreaterThan4);
        return mongoTemplate.aggregate(aggregation, "Courses", MCourses.class).getMappedResults();


    }
}
