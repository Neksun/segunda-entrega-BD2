package edu.uao.project.backend.Service;

import edu.uao.project.backend.Model.MCourses;

import java.util.List;

public interface ISCourse {

    String crearCurso(MCourses course);


}
