package edu.uao.project.backend.Controller;

import edu.uao.project.backend.Model.MTutors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TutorCourseProjection {
    private String nombreCurso;
    private Double ratingCurso;
    private ObjectId curso_id;
    private List<MTutors> infoTutor;
}
