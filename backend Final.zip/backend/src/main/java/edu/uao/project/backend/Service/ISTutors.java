package edu.uao.project.backend.Service;

import edu.uao.project.backend.Model.MCourses;
import edu.uao.project.backend.Model.MTutors;
import org.springframework.web.bind.annotation.RequestBody;

public interface ISTutors {
    String crearTutors(MTutors tutors);
}
