package edu.uao.project.backend.Controller;

import edu.uao.project.backend.Model.MUsers;
import edu.uao.project.backend.Repository.IRUsers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Users")
public class CUsers {
    @Autowired
    private IRUsers usersRepository;

    @PostMapping("/")
    public ResponseEntity<MUsers> crearUser(@RequestBody MUsers users) {
        MUsers savedUser = usersRepository.save(users); // Save the course to the database
        return ResponseEntity.ok(savedUser); // Return the saved course with HTTP status 200 (OK)
    }
}
