package edu.uao.project.backend.Service;

import edu.uao.project.backend.Model.MUsers;

public interface ISUsers {
    String crearUser(MUsers users);
}
