package edu.uao.project.backend.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "TutorCourse")
public class MTutorCourse {
    @Id
    private ObjectId _id;
    private String nombreTutor;
    private ObjectId Tutor_id;
    private Curso cursos;

    public static class Curso {
        private String nombreCurso;
        private CursoId Curso_Id;

    }
    public static class CursoId {
        private ObjectId $oid;

    }
}
