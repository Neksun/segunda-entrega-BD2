package edu.uao.project.backend.Repository;

import edu.uao.project.backend.Model.MUsers;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IRUsers extends MongoRepository<MUsers,ObjectId> {
}
