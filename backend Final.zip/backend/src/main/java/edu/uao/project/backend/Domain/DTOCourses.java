package edu.uao.project.backend.Domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DTOCourses {
    private ObjectId _id;
    private String name;
    private String category;
    private Double price;
    private Integer totalHours;
    private Double Rating;
}
