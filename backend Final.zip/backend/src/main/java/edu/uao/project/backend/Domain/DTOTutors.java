package edu.uao.project.backend.Domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DTOTutors {
    private ObjectId _id;
    private String nombreT;
    private String carrera;
    private Integer semestre;
    private Double calificacion_promedio;
}
