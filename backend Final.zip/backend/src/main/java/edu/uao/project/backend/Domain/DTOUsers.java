package edu.uao.project.backend.Domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DTOUsers {
    private ObjectId _id;
    private String nombre;
    private String carrera;
    private Integer semestre;
}
